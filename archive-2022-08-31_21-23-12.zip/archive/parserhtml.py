from re import L
from time import sleep
from bs4 import BeautifulSoup
import os, json


def bs4pars():

	soup = BeautifulSoup(html,'lxml')


def main():
	bs4pars()


if __name__ == "__main__":
	main()